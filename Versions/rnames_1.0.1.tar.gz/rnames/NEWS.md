## Changes in 1.0.1

+ Added method dispatch.